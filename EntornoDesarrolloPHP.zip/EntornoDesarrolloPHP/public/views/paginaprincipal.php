<!--
    Vista de la página inicio. Página principal por dónde se accede.
-->

<div style="background-color: #864ddf;">
    <center>
        <img src="assets/paginainicio.png" width="60%" height="60%">
    </center>
</div>


